brew install ffmpeg
