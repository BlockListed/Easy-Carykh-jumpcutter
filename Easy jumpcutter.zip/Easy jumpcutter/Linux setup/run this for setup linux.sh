sudo pip install pillow
sudo pip install audiotsm
sudo pip install scipy
sudo pip install pytube
sudo apt install ffmpeg
